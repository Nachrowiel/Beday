# HTML & CSS Birthday Folded Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/lenasta92579651/pen/KKvmGpL](https://codepen.io/lenasta92579651/pen/KKvmGpL).

